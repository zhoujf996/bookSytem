package com.neusoft.dao;

import java.sql.*;

public class BaseDao {
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/book2?serverTimezone=UTC";
    private static final String UID = "root";
    private static final String PWD = "root";

    private Connection conn = null;
    private PreparedStatement ppst = null;
    private ResultSet rs = null;


    public void getConnection() {
        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, UID, PWD);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //增删改,返回int类型
    public int executeUpdate(String sql, Object... params) {
        int result = -1;
        try {
            getConnection();
            ppst = conn.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                ppst.setObject(i + 1, params[i]);
            }
            result = ppst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeAll();
        }
        return result;
    }


    //查询,返回一个结果集，属于ResultSet类型
    public ResultSet executeQuery(String sql, Object... params) {
        try {
            getConnection();
            ppst = conn.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                ppst.setObject(i + 1, params[i]);
            }
            rs = ppst.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }


    public void closeAll() {
        try {
            if (rs != null) rs.close();
            if (ppst != null) ppst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
