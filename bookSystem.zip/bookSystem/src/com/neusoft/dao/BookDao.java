package com.neusoft.dao;

import com.neusoft.entity.Book;
import com.neusoft.entity.Publisher;

import java.util.List;

public interface BookDao {
    //添加
    int add(Book book, Publisher p);

    //删除,根据书本名称
    int delete(int bid);

    //修改图书价格
    int update(int price, String bname);

    //修改图书信息
    int updateBookInfo(Book b, Publisher p);

    //查询全部
    List<Book> getAll();

    //根据bid查询
    Book getById(int bid);

    //根据名字查询
    List<Book> getByName(String bname);

    //根据作者查询
    List<Book> getByAuthor(String name);

    //模糊查询
    List<Book> getAllBylike(String bname);

    String getBookName(int bid);

    //用于查询书籍是否存在的方法
    int getBookById(int bid);

}
