package com.neusoft.dao;

import com.neusoft.entity.Users;

import java.util.List;

public interface UsersDao {

    //判断用户是否存在
    int usersTest(String uname);

    //登录
    int login(Users u);

    //添加
    int add(Users u);

    //删除
    int delete(String uname);

    //修改
    int update(String pwd, String uname);

    //查询全部
    List<Users> getAll();

    //根据id查询
    Users getById(int uid);

    //根据名字查询
    Users getByName(String uname);

    //根据名字查看权限
    int getPowerByName(String uname);

}
