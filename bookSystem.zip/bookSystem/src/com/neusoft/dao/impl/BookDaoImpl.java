package com.neusoft.dao.impl;

import com.neusoft.dao.BaseDao;
import com.neusoft.dao.BookDao;
import com.neusoft.entity.Book;
import com.neusoft.entity.Publisher;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookDaoImpl extends BaseDao implements BookDao {
    BaseDao bd = new BaseDao();

    //添加
    public int add(Book book, Publisher p) {
        int re = -1;
        String sql = "INSERT INTO book(bname,price,author,pid) VALUES(?,?,?,?)";
        re = bd.executeUpdate(sql, book.getBname(), book.getPrice(), book.getAuthor(), p.getPid());
        return re;
    }

    //删除
    public int delete(int bid) {
        int re = -1;
        String sql = "DELETE FROM book WHERE bid=?";
        re = bd.executeUpdate(sql, bid);
        return re;

    }

    //更新价格
    public int update(int price, String bname) {
        int re = -1;
        String sql = "UPDATE book SET price=? WHERE bname= ? ";
        re = bd.executeUpdate(sql, price, bname);
        return re;

    }


    //修改书籍信息
    public int updateBookInfo(Book b, Publisher p) {
        int re = 1;
        String sql = "UPDATE  book b  SET  b.`bname`= ? , b.`price`=? , b.`author`=? , b.`pid` =?  WHERE  b.`bid`=? ";
        re = bd.executeUpdate(sql, b.getBname(), b.getPrice(), b.getAuthor(), p.getPid(), b.getBid());
        return re;
    }


    //查询全部
    public List<Book> getAll() {
        List<Book> blist = new ArrayList<Book>();
        String sql = "SELECT b.*,p.`pname` FROM book b JOIN publisher p ON b.`pid`=p.`pid`";
        ResultSet rs = bd.executeQuery(sql);
        Book b = null;
        try {
            while (rs.next()) {
                b = new Book();
                b.setBid(rs.getInt(1));
                b.setBname(rs.getString(2));
                b.setPrice(rs.getInt(3));
                b.setAuthor(rs.getString(4));
                Publisher p = new Publisher();
                p.setPid(rs.getInt(5));
                p.setPname(rs.getString(6));
                b.setPublisher(p);
                blist.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return blist;
    }

    //根据id查询
    public Book getById(int bid) {
        Book b = new Book();
        List<Book> blist = new ArrayList<Book>();
        String sql = "SELECT b.*,p.`pname` FROM book b,publisher p WHERE b.`pid`=p.`pid` and bid=?";
        ResultSet rs = bd.executeQuery(sql, bid);
        try {
            if (rs.next()) {
                b = new Book();
                b.setBid(rs.getInt(1));
                b.setBname(rs.getString(2));
                b.setPrice(rs.getInt(3));
                b.setAuthor(rs.getString(4));
                Publisher p = new Publisher();
                p.setPid(rs.getInt(5));
                p.setPname(rs.getString(6));
                b.setPublisher(p);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }

    //用于根据Id查询图书是否存在
    public int getBookById(int bid) {
        int re = -1;
        String sql = "SELECT  COUNT(*)  FROM   book  b   WHERE   b.`bid`= ? ";
        ResultSet rs = bd.executeQuery(sql, bid);
        try {
            if (rs.next()) {
                re = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return re;
    }


    //根据作者名字查询
    public List<Book> getByAuthor(String author) {
        Book b = new Book();
        List<Book> blist = new ArrayList<Book>();
        String sql = "SELECT b.*,p.`pname` FROM book b JOIN publisher p ON b.`pid`=p.`pid` WHERE author = ? ";
        ResultSet rs = bd.executeQuery(sql, author);
        try {
            while (rs.next()) {
                b = new Book();
                b.setBid(rs.getInt(1));
                b.setBname(rs.getString(2));
                b.setPrice(rs.getInt(3));
                b.setAuthor(rs.getString(4));
                Publisher p = new Publisher();
                p.setPid(rs.getInt(5));
                p.setPname(rs.getString(6));
                b.setPublisher(p);
                blist.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return blist;
    }

    //根据书籍名字查询
    public List<Book> getByName(String bname) {
        Book b = new Book();
        List<Book> blist = new ArrayList<Book>();
        String sql = "SELECT b.*,p.`pname` FROM book b JOIN publisher p ON b.`pid`=p.`pid` WHERE bname = ?";
        ResultSet rs = bd.executeQuery(sql, bname);
        try {
            while (rs.next()) {
                b = new Book();
                b.setBid(rs.getInt(1));
                b.setBname(rs.getString(2));
                b.setPrice(rs.getInt(3));
                b.setAuthor(rs.getString(4));
                b.setPublisher(new Publisher(rs.getInt(5), rs.getString(6)));
                blist.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return blist;
    }


    //模糊查询
    public List<Book> getAllBylike(String bname) {
        List<Book> blist = new ArrayList<Book>();
        Book b = null;
        String sql = "SELECT b.*,p.`pname` FROM book b,publisher p WHERE b.`pid`=p.`pid` AND bname LIKE ? ";
        ResultSet rs = bd.executeQuery(sql, "%" + bname + "%");
        try {
            while (rs.next()) {
                b = new Book();
                b.setBid(rs.getInt(1));
                b.setBname(rs.getString(2));
                b.setPrice(rs.getInt(3));
                b.setAuthor(rs.getString(4));
                Publisher p = new Publisher();
                p.setPid(rs.getInt(5));
                p.setPname(rs.getString(6));
                b.setPublisher(p);
                blist.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return blist;
    }

    //获取书本的名字
    public String getBookName(int bid) {
        String str = null;
        String sql = "SELECT bname FROM book WHERE bid= ? ";
        ResultSet rs = bd.executeQuery(sql, bid);
        try {
            if (rs.next()) {
                str = rs.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return str;
    }

}
