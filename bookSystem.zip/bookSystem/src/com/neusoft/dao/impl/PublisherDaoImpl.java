package com.neusoft.dao.impl;

import com.neusoft.dao.BaseDao;
import com.neusoft.dao.PublisherDao;
import com.neusoft.entity.Publisher;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PublisherDaoImpl extends BaseDao implements PublisherDao {
    BaseDao bd = new BaseDao();

    //添加出版社
    public int add(Publisher p) {
        int re = -1;
        String sql = "INSERT INTO publisher (pname) VALUES(?)";
        re = bd.executeUpdate(sql, p.getPname());
        return re;

    }

    //删除出版社
    public int delete(int pid) {
        int re = -1;
        String sql = "DELETE FROM publisher WHERE pid=?";
        re = bd.executeUpdate(sql, pid);
        return re;

    }

    //修改出版社
    public int update(Publisher p) {
        int re = -1;
        String sql = "UPDATE publisher SET pname=? WHERE pid=?";
        re = bd.executeUpdate(sql, p.getPname(), p.getPid());
        return re;
    }

    //查询所有信息
    public List<Publisher> getAll() {
        List<Publisher> plist = new ArrayList<Publisher>();
        Publisher pub = null;
        String sql = "SELECT * FROM publisher";
        ResultSet rs = bd.executeQuery(sql);
        try {
            while (rs.next()) {
                pub = new Publisher();
                pub.setPid(rs.getInt(1));
                pub.setPname(rs.getString(2));
                plist.add(pub);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return plist;

    }

    //根据pid查询信息
    public Publisher getById(int pid) {
        Publisher p = null;
        String sql = "SELECT * FROM publisher WHERE pid=?";
        ResultSet rs = bd.executeQuery(sql, pid);
        try {
            while (rs.next()) {
                p = new Publisher();
                p.setPid(rs.getInt(1));
                p.setPname(rs.getString(2));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }

    //根据出版社名字查询信息
    public Publisher getByName(String pname) {
        Publisher p = null;
        String sql = "SELECT * FROM publisher WHERE pname=?";
        ResultSet rs = bd.executeQuery(sql, pname);
        try {
            while (rs.next()) {
                p = new Publisher();
                p.setPid(rs.getInt(1));
                p.setPname(rs.getString(2));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }

}
