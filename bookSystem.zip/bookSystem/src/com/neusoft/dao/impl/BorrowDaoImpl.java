package com.neusoft.dao.impl;

import com.neusoft.dao.BaseDao;
import com.neusoft.dao.BorrowDao;
import com.neusoft.entity.Borrow;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BorrowDaoImpl extends BaseDao implements BorrowDao {
    BaseDao bd = new BaseDao();

    //根据id查出借阅列表，用于判断书籍是否被借阅
    public int getAllById(int bid) {
        String sql = "SELECT   COUNT(*)  FROM  borrow b  WHERE   b.`bid`=  ? ";
        ResultSet rs = bd.executeQuery(sql, bid);
        int re = -1;
        try {
            if (rs.next()) {
                re = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return re;
    }

    //添加借阅列表，用于借阅书籍
    public int add(int bid, String uname) {
        int re = -1;
        String sql = "INSERT  INTO  borrow(bid, uname, borrowdate) VALUES( ? , ? , CURDATE() )";
        re = bd.executeUpdate(sql, bid, uname);
        return re;
    }


    //查询借阅表,根据用户名字查询
    public List<Borrow> getAll(String uname) {
        List<Borrow> blist = new ArrayList<Borrow>();
        Borrow borrow = null;
        String sql = "SELECT  *  FROM   borrow b   WHERE   b.`uname`= ?";
        ResultSet rs = bd.executeQuery(sql, uname);
        try {
            while (rs.next()) {
                borrow = new Borrow();
                borrow.setBid(rs.getInt(1));
                borrow.setUname(rs.getString(2));
                borrow.setBorrowDate(rs.getString(3));
                blist.add(borrow);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return blist;
    }


    //删除表信息,用于还书
    public int delete(int bid) {
        int re = -1;
        String sql = "DELETE FROM  borrow   WHERE  borrow.`bid`= ? ";
        re = bd.executeUpdate(sql, bid);
        return re;
    }


    //根据用户名查出借阅列表，用于判断书籍是否被借阅
    public int getAllByUname(String uname) {
        String sql = "SELECT  COUNT(*)  FROM   borrow b   WHERE   b.`uname`= ? ";
        ResultSet rs = bd.executeQuery(sql, uname);
        int re = -1;
        try {
            if (rs.next()) {
                re = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return re;
    }

}
