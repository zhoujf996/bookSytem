package com.neusoft.dao.impl;


import com.neusoft.dao.BaseDao;
import com.neusoft.dao.UsersDao;
import com.neusoft.entity.Users;
import com.sun.org.apache.bcel.internal.generic.IUSHR;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UsersDaoImpl extends BaseDao implements UsersDao {
    BaseDao bd = new BaseDao();

    //用于检测用户是否存在
    public int usersTest(String uname) {
        int re = -1;
        String sql = "SELECT COUNT(*) FROM users WHERE uname=?";
        ResultSet rs = bd.executeQuery(sql, uname);
        try {
            if (rs.next()) {
                re = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return re;
    }

    public int add(Users u) {
        int re = -1;
        String sql = "INSERT INTO users(uname,pwd,powers) VALUES(?,?,?)";
        re = bd.executeUpdate(sql, u.getUname(), u.getPwd(), 0);
        return re;
    }

    public int login(Users u) {
        int re = -1;
        String sql = "SELECT  COUNT(*) FROM users WHERE uname=? AND pwd=?";
        ResultSet rs = bd.executeQuery(sql, u.getUname(), u.getPwd());
        try {
            if (rs.next()) {
                re = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return re;
    }

    public int delete(String uname) {
        int re = -1;
        String sql = "DELETE FROM users WHERE uname=?";
        re = bd.executeUpdate(sql, uname);
        return re;
    }

    public int update(String pwd, String uname) {
        int re = -1;
        String sql = "UPDATE users SET pwd=? WHERE uname=?";
        re = bd.executeUpdate(sql, pwd, uname);
        return re;
    }

    public List<Users> getAll() {
        List<Users> ulist = new ArrayList<Users>();
        Users u = null;
        String sql = "SELECT * FROM users";
        ResultSet rs = bd.executeQuery(sql);
        try {

            while (rs.next()) {
                u = new Users();
                u.setUid(rs.getInt(1));
                u.setUname(rs.getString(2));
                u.setPwd(rs.getString(3));
                u.setPowers(rs.getInt(4));
                ulist.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ulist;
    }

    public Users getById(int uid) {
        Users u = new Users();
        String sql = "SELECT * FROM users WHERE uid=?";
        ResultSet rs = bd.executeQuery(sql, uid);
        try {
            if (rs.next()) {
                u.setUid(rs.getInt(1));
                u.setUname(rs.getString(2));
                u.setPwd(rs.getString(3));
                u.setPowers(rs.getInt(4));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return u;
    }

    public Users getByName(String uname) {
        String sql = "SELECT * FROM users WHERE uname=?";
        ResultSet rs = bd.executeQuery(sql, uname);
        Users u = null;
        try {
            if (rs.next()) {
                u = new Users();
                u.setUid(rs.getInt(1));
                u.setUname(rs.getString(2));
                u.setPwd(rs.getString(3));
                u.setPowers(rs.getInt(4));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return u;
    }

    public int getPowerByName(String uname) {
        int re = -1;
        String sql = "SELECT * FROM users WHERE uname=?";
        ResultSet rs = bd.executeQuery(sql, uname);
        try {
            if (rs.next()) {
                Users u = new Users();
                u.setPowers(rs.getInt(4));
                re = u.getPowers();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return re;
    }

}
