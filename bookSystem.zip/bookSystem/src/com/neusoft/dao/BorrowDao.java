package com.neusoft.dao;


import com.neusoft.entity.Borrow;

import java.util.List;

public interface BorrowDao {

    //根据id查出借阅列表，用于判断书籍是否被借阅
    int getAllById(int bid);

    //添加借阅列表，用于借阅书籍
    int add(int bid, String uname);

    //查询借阅表,根据用户名字查询
    List<Borrow> getAll(String uname);

    //删除表信息,用于还书
    int delete(int bid);

    int getAllByUname(String uname);
}
