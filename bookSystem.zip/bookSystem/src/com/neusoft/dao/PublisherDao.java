package com.neusoft.dao;

import com.neusoft.entity.Publisher;

import java.util.List;

public interface PublisherDao {

    //添加
    int add(Publisher p);

    //删除
    int delete(int pid);

    //修改
    int update(Publisher p);

    //查询全部
    List<Publisher> getAll();

    //根据id查询
    Publisher getById(int pid);

    //根据出版社名字查询
    Publisher getByName(String pname);
}
