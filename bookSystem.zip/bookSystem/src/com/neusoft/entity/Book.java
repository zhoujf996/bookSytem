package com.neusoft.entity;

public class Book {
    private int bid;
    private String bname;
    private int price;
    private String author;
    private int bstatus;
    private Publisher publisher;

    public Book() {
    }

    public Book(String bname) {
        this.bname = bname;
    }

    public Book(int bid, String bname, int price, String author, Publisher publisher, int bstatus) {
        this.bid = bid;
        this.bname = bname;
        this.price = price;
        this.author = author;
        this.publisher = publisher;
        this.bstatus = bstatus;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public String getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname = bname;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Publisher getPublisher() {
        return publisher;
    }

    public void setPublisher(Publisher publisher) {
        this.publisher = publisher;
    }

    public int getBstatus() {
        return bstatus;
    }


    public void setBstatus(int bstatus) {
        this.bstatus = bstatus;
    }

    @Override
    public String toString() {
        return bid + "\t" + bname + "\t" + price + "\t" + author
                + "\t" + bstatus + "\t" + publisher;
    }
}
