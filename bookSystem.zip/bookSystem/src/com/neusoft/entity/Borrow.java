package com.neusoft.entity;

import java.util.Date;

public class Borrow {
    private int bid;
    private String uname;
    private String borrowDate;


    public Borrow() {
    }

    public Borrow(int bid, String uname, String borrowDate) {
        this.bid = bid;
        this.uname = uname;
        this.borrowDate = borrowDate;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    @Override
    public String toString() {
        return bid +"\t" + uname + "\t" + borrowDate;

    }
}
