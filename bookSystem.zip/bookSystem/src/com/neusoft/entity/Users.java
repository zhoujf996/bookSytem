package com.neusoft.entity;

public class Users {
    private int uid;
    private String uname;
    private String pwd;
    private int powers;

    public Users() {
    }

    public Users(int uid, String uname, String pwd, int powers) {
        this.uid = uid;
        this.uname = uname;
        this.pwd = pwd;
        this.powers = powers;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public int getPowers() {
        return powers;
    }

    public void setPowers(int powers) {
        this.powers = powers;
    }

    @Override
    public String toString() {
        return uid + "\t" + uname + "\t" + pwd + "\t" + powers;
    }

}
