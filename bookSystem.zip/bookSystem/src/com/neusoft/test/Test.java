package com.neusoft.test;

public class Test {
    public static void main(String[] args){
        BookManager bk=new BookManager();
        bk.managerMenu();

    }
}
