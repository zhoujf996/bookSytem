package com.neusoft.test;

import com.neusoft.dao.BaseDao;
import com.neusoft.dao.BookDao;
import com.neusoft.dao.BorrowDao;
import com.neusoft.dao.UsersDao;
import com.neusoft.dao.impl.BookDaoImpl;
import com.neusoft.dao.impl.BorrowDaoImpl;
import com.neusoft.dao.impl.UsersDaoImpl;
import com.neusoft.entity.Book;
import com.neusoft.entity.Borrow;
import com.neusoft.entity.Publisher;
import com.neusoft.entity.Users;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/*
普通用户能做什么？
修改自己的密码
查看所有图书
根据书名查询
根据作者查询
租借

管理员？
查看所有图书
修改密码
修改图书信息
新增图书
删除图书
删除用户

 */
public class BookManager {

    //主菜单
    public void managerMenu() {
        Scanner sc = new Scanner(System.in);
        System.out.println("***********欢迎来到图书管理系统*************");
        System.out.println("**********1.用户登录  2.用户注册************");
        System.out.println("*************请输入要进行的操作：***********");
        int num = sc.nextInt();
        switch (num) {
            case 1:
                System.out.println("******欢迎进入用户登录界面**********");
                login();//跳转到登录方法
                break;
            case 2:
                System.out.println("*******欢迎进入用户注册界面*********");
                regist();//跳转到注册方法
                break;
            default:
                System.out.println("抱歉，您的输入有误！");
                break;
        }
    }

    //普通用户界面
    public void userMenu(String uname) {
        Scanner sc = new Scanner(System.in);
        System.out.println("***************欢迎进入普通用户界面***************");
        System.out.println("*****************1.修改自己的密码*****************");
        System.out.println("*****************2.查看所有图书*******************");
        System.out.println("*****************3.根据书名查询*******************");
        System.out.println("*****************4.根据作者查询*******************");
        System.out.println("*****************5.租借***************************");
        System.out.println("*****************6.还书***************************");
        System.out.println("*****************7.模糊查询***********************");
        System.out.println("*****************9.返回上一层*********************");
        System.out.println("*****************0.退出系统***********************");
        System.out.println("*****************请输入所需的操作：***************");
        int num = sc.nextInt();
        switch (num) {
            case 1:
                updatePwd(uname);//调用到修改密码的方法
                break;
            case 2:
                getAllBook(uname);//调用到查询所有书籍的方法
                break;
            case 3:
                getBookByName(uname);//调用到根据书本名称查询的方法
                break;
            case 4:
                getBookByAuthor(uname);//调用到根据书籍作者查询的方法
                break;
            case 5:
                borrowMenu(uname);//调用到借阅界面
                break;
            case 6:
                backBookMenu(uname);//调用到还书界面
                break;
            case 7:
                getBookByLike(uname);//调用模糊查询方法
                break;
            case 9:
                managerMenu();//返回到主界面
                break;
            case 0:
                System.out.println("下次再会！");
                exit();//退出系统方法
                break;
            default:
                System.out.println("抱歉，输入有误！");
                userMenu(uname);//用户界面方法
                break;
        }

    }


    //管理员界面
    public void adminMenu(String uname) {
        Scanner sc = new Scanner(System.in);
        System.out.println("***************欢迎进入管理员界面*****************");
        System.out.println("*****************1.查看所有图书*******************");
        System.out.println("*****************2.修改密码***********************");
        System.out.println("*****************3.修改图书信息*******************");
        System.out.println("*****************4.修改图书价格*******************");
        System.out.println("*****************5.新增图书***********************");
        System.out.println("*****************6.删除图书***********************");
        System.out.println("*****************7.删除用户***********************");
        System.out.println("*****************9.返回上一层*********************");
        System.out.println("*****************0.退出系统***********************");
        System.out.println("*****************请输入执行的操作：***************");
        int num = sc.nextInt();
        switch (num) {
            case 1:
                getAllBook(uname);//查询所有书籍
                break;
            case 2:
                updatePwd(uname);//修改密码
                break;
            case 3:
                updateBookInfo(uname);//修改所有书籍信息
                break;
            case 4:
                updateBookPrice(uname);//修改书籍价格
                break;
            case 5:
                addBook(uname);//添加书籍
                break;
            case 6:
                deleteBook(uname);//删除书籍
                break;
            case 7:
                deleteUsers(uname);//删除用户
                break;
            case 9:
                managerMenu();//主菜单
                break;
            case 0:
                System.out.println("下次再会！");
                exit();//退出系统
                break;
            default:
                System.out.println("输入有误！");
                adminMenu(uname);//管理员菜单
                break;
        }
    }

    //借书界面
    public void borrowMenu(String uname) {
        Scanner sc = new Scanner(System.in);
        System.out.println("*****************欢迎进入借阅界面******************");
        System.out.println("*****************1.借书****************************");
        System.out.println("*****************2.返回上一层菜单******************");
        System.out.println("*****************请输入所需要的操作：**************");
        int num = sc.nextInt();
        switch (num) {
            case 1:
                borrowBook(uname);//借书方法
                break;
            case 2:
                userMenu(uname);//返回用户菜单
                break;
            default:
                System.out.println("输入有误！");
                borrowMenu(uname);//返回借书界面
                break;
        }
    }

    //还书界面
    public void backBookMenu(String uname) {
        Scanner sc = new Scanner(System.in);
        System.out.println("*************欢迎进入还书界面**************");
        System.out.println("***************1.还书**********************");
        System.out.println("***************2.返回上一层菜单************");
        System.out.println("***************请输入所需要的操作：********");
        int num = sc.nextInt();
        switch (num) {
            case 1:
                isBorrowByUname(uname);//根据用户名查询是否有借阅书籍
                break;
            case 2:
                userMenu(uname);//返回到用户菜单
                break;
            default:
                System.out.println("输入有误！");
                backBookMenu(uname);//如果输入有误返回还书界面
                break;
        }

    }

    //登录方法
    public void login() {
        Scanner sc = new Scanner(System.in);
        UsersDao ud = new UsersDaoImpl();
        Users u = new Users();
        System.out.println("输入用户名：");
        u.setUname(sc.next());
        String uname = u.getUname();
        if (ud.usersTest(u.getUname()) > 0) {//检测用户是否存在
            System.out.println("请输入密码：");
            u.setPwd(sc.next());
            if (ud.login(u) > 0) {//调用bookDaoImpl中的登录方法
                System.out.println("登录成功！");
                identified(uname);//检测是普通用户还是管理员的方法
            } else {
                System.out.println("抱歉，密码错误！");
                managerMenu();//返回主菜单
            }
        } else {
            System.out.println("用户名不存在！");
            managerMenu();//返回主菜单

        }
    }

    //注册方法
    public void regist() {
        Scanner sc = new Scanner(System.in);
        UsersDao ud = new UsersDaoImpl();
        Users u = new Users();
        System.out.println("输入用户名：");
        u.setUname(sc.next());
        if (ud.usersTest(u.getUname()) > 0) {//检测用户是否存在，如果不存在则可以输入密码注册
            System.out.println("抱歉，用户名已存在");
            managerMenu();
        } else {
            System.out.println("请输入密码：");
            u.setPwd(sc.next());
            if (ud.add(u) > 0) {//调用UsersDaoImpl中的add方法
                System.out.println("注册成功！");
                managerMenu();//返回用户主菜单
            } else {
                System.out.println("抱歉，注册失败！");
                managerMenu();
            }
        }
    }


    //判断是管理员还是普通用户
    public void identified(String uname) {
        UsersDaoImpl u = new UsersDaoImpl();
        int re = -1;
        re = u.getPowerByName(uname);
        if (re == 1) {//进入管理员界面
            adminMenu(uname);
        } else if (re == 0) {//进入普通用户界面
            userMenu(uname);
        } else {
            System.out.println("抱歉，系统出现异常");
        }
    }


    //修改自己的密码(普通用户)
    public void updatePwd(String uname) {
        System.out.println("请输入要修改的密码：");
        Scanner sc = new Scanner(System.in);
        String pwd = sc.next();
        UsersDao bd = new UsersDaoImpl();
        int re = bd.update(pwd, uname);//调用修改UserDaoImpl中的修改方法
        if (re > 0) {
            System.out.println("修改成功");
            identified(uname);//修改成功之后根据用户返回相应的菜单
        } else {
            System.out.println("修改失败");
            identified(uname);//修改成功之后根据用户返回相应的菜单
        }
    }

    //查询所有图书(普通用户)
    public void getAllBook(String uname) {
        BookDaoImpl bd = new BookDaoImpl();
        List<Book> blist = new ArrayList<Book>();
        blist = bd.getAll();
        for (Book book : blist) {//遍历集合输出内容
            System.out.println(book);
        }
        identified(uname);//查询成功之后返回相应的界面
    }


    //查询所有的图书(不返回界面)，用于借阅界面
    public void getAllBookBorrow(String uname) {
        BookDaoImpl bd = new BookDaoImpl();
        List<Book> blist = new ArrayList<Book>();
        blist = bd.getAll();
        for (Book book : blist) {//遍历集合返回数据
            System.out.println(book);//输出之后不返回任何界面
        }
    }

    //根据书名查询书籍
    public void getBookByName(String uname) {
        System.out.println("请输入书名：");
        Scanner sc = new Scanner(System.in);
        BookDaoImpl bd = new BookDaoImpl();
        List<Book> blist = new ArrayList<Book>();
        blist = bd.getByName(sc.next());
        for (Book book : blist) {//遍历集合返回数据
            System.out.println(book);
        }
        userMenu(uname);//返回用户菜单
    }

    //根据作者名字查询书籍
    public void getBookByAuthor(String uname) {
        System.out.println("请输入作者名字：");
        Scanner sc = new Scanner(System.in);
        BookDaoImpl bd = new BookDaoImpl();
        List<Book> blist = new ArrayList<Book>();
        blist = bd.getByAuthor(sc.next());
        for (Book book : blist) {//遍历集合
            System.out.println(book);
        }
        userMenu(uname);//返回用户菜单
    }


    //借书方法
    public void borrowBook(String uname) {
        Scanner sc = new Scanner(System.in);
        BorrowDao b = new BorrowDaoImpl();
        getAllBookBorrow(uname);//先查询出所有书籍
        System.out.println("请输入要借阅的书籍id：");
        int bid = sc.nextInt();
        int re = isBookExist(bid);//检测所要借的书籍是否存在
        if (re > 0) {
            if (isBorrow(bid) <= 0) {
                b.add(bid, uname);
                System.out.println("借书成功");
                borrowMenu(uname);
            } else {
                System.out.println("抱歉，此书已经被借阅");
                borrowMenu(uname);//返回借书界面
            }
        } else {
            System.out.println("抱歉，无此书籍");
            borrowMenu(uname);//返回借书界面
        }
    }


    //检查书籍是否被借阅
    public int isBorrow(int bid) {
        int re = -1;
        BorrowDao bd = new BorrowDaoImpl();
        re = bd.getAllById(bid);//根据书本id查询借阅表
        return re;
    }


    //还书方法
    public void backBook(String uname) {
        BorrowDao borrowDao = new BorrowDaoImpl();
        Scanner sc = new Scanner(System.in);
        System.out.println("已借阅书籍列表");
        getAllBorrow(uname);//根据用户名查询借阅表，判断是否有借书
        System.out.println("请输入要还的书籍id:");
        int bid = sc.nextInt();
        int re = borrowDao.delete(bid);
        if (re > 0) {
            System.out.println("归还成功，欢迎下次借阅");
            backBookMenu(uname);
        } else {
            System.out.println("归还未成功，请重新归还");
            borrowBook(uname);
        }
    }


    //模糊查询
    public void getBookByLike(String uname) {
        List<Book> blist = new ArrayList<Book>();
        BookDao bd = new BookDaoImpl();
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入要查询的书籍：");
        blist = bd.getAllBylike(sc.next());
        for (Book book : blist) {
            System.out.println(book);
        }
        userMenu(uname);
    }

    //修改图书信息
    public void updateBookInfo(String uname) {
        Scanner sc = new Scanner(System.in);
        BookDaoImpl bd = new BookDaoImpl();
        Book book = new Book();
        System.out.println("请输入要修改图书的id：");
        book.setBid(sc.nextInt());
        System.out.println("请修改书籍名称：");
        book.setBname(sc.next());
        System.out.println("请修改书籍价格：");
        book.setPrice(sc.nextInt());
        System.out.println("请修改书籍作者：");
        book.setAuthor(sc.next());
        System.out.println("请修改书籍出版社id：");
        Publisher p = new Publisher();
        p.setPid(sc.nextInt());
        int re = bd.updateBookInfo(book, p);
        if (re > 0) {
            System.out.println("修改成功！");
            adminMenu(uname);
        } else {
            System.out.println("修改失败！");
            adminMenu(uname);
        }
    }

    //修改图书价格
    public void updateBookPrice(String uname) {
        BookDao bd = new BookDaoImpl();
        Scanner sc = new Scanner(System.in);
        Book book = new Book();
        System.out.println("请输入图书名称:");
        String bname = sc.next();
        System.out.println("请输入图书要修改价格：");
        int price = sc.nextInt();
        int re = bd.update(price, bname);
        if (re > 0) {
            System.out.println("修改成功");
            adminMenu(uname);
        } else {
            System.out.println("修改失败");
            adminMenu(uname);
        }
    }


    //新增图书
    public void addBook(String uname) {
        Scanner sc = new Scanner(System.in);
        BookDao bd = new BookDaoImpl();
        Book book = new Book();
        System.out.println("请输入书籍名称：");
        book.setBname(sc.next());
        System.out.println("请输入书籍价格：");
        book.setPrice(sc.nextInt());
        System.out.println("请输入书籍作者：");
        book.setAuthor(sc.next());
        System.out.println("请输入书籍出版社id：");
        Publisher p = new Publisher();
        p.setPid(sc.nextInt());
        int re = bd.add(book, p);
        if (re > 0) {
            System.out.println("新增成功");
            adminMenu(uname);
        } else {
            System.out.println("新增失败");
            adminMenu(uname);
        }
    }

    //删除图书
    public void deleteBook(String uname) {
        Scanner sc = new Scanner(System.in);
        BookDaoImpl bd = new BookDaoImpl();
        System.out.println("请输入要删除书籍的id:");
        int bid = sc.nextInt();
        int re = bd.delete(bid);
        if (re > 0) {
            System.out.println("删除成功");
            adminMenu(uname);
        } else {
            System.out.println("删除成功");
            adminMenu(uname);
        }
    }

    //删除用户
    public void deleteUsers(String uname) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入要删除的用户名字：");
        String username = sc.next();
        UsersDao u = new UsersDaoImpl();
        int re = u.delete(username);
        if (re > 0) {
            System.out.println("删除成功");
            adminMenu(uname);
        } else {
            System.out.println("删除失败");
            adminMenu(uname);
        }
    }

    //根据书本id查看书本是否存在
    public int isBookExist(int bid) {
        int re = -1;
        BookDao b = new BookDaoImpl();
        re = b.getBookById(bid);
        return re;
    }


    //查询借阅表所有信息
    public void getAllBorrow(String uname) {
        List<Borrow> blist = new ArrayList<Borrow>();
        BorrowDao borrowDao = new BorrowDaoImpl();
        blist = borrowDao.getAll(uname);
        for (Borrow borrow : blist) {
            System.out.println(borrow);
        }
    }

    //查看用户是否有借阅的书籍
    public void isBorrowByUname(String uname) {
        int re = -1;
        BorrowDao b = new BorrowDaoImpl();
        re = b.getAllByUname(uname);
        if (re <= 0) {
            System.out.println("您还没有借阅书籍");
            backBookMenu(uname);
        } else {
            backBook(uname);
        }
    }

    //退出系统
    public void exit() {
        System.exit(0);
    }
}
